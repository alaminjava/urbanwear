# UrbanWear MERN Fashion eCommerce Platform

UrbanWear is a fashion-focused MERN ecommerce project updated to match the supplied Software Requirements Specification (SRS). It supports trend-based clothing shopping, size/color product variants, customer checkout, wishlist, address management, collections, order tracking, and an admin dashboard.

## Tech stack

- React 18 + Vite
- Express 4 + Node.js
- MongoDB + Mongoose
- Axios
- React Router

## Main SRS features implemented

- UrbanWear branding and black/white modern UI theme
- Fashion categories: Men, Women, Streetwear, Accessories
- Product variants: size, color, and variant-level stock
- Product filters by category, size, color, price, stock, search, and sort
- Product details with image gallery, size selection, color selection, stock availability, and add to cart
- Authenticated checkout only; guests can browse but cannot purchase
- Cart items and order items preserve selected size/color
- Customer dashboard with order history, order status, wishlist, profile update, and address management
- Admin dashboard for overview, products, inventory, orders, users, and collections
- Collections model and admin collection management for seasonal drops
- JWT-style token auth, password hashing, role-based authorization, and API rate limiting
- SRS-compatible route aliases in addition to existing `/api/store/...` routes

## Quick start

```bash
npm install
cp .env.example .env
npm run dev
```

The dev script starts the backend on an available port beginning with `5001` and the frontend on an available port beginning with `5173`.

For production build:

```bash
npm run build
npm start
```

## Required environment variables

```env
PORT=5001
MONGODB_URI=mongodb://127.0.0.1:27017/UrbanWear
MONGODB_DB=
CORS_ORIGIN=http://localhost:5173
VITE_API_URL=/api
ENABLE_DEMO_ACCOUNTS=true
ENABLE_STORE_DEMO_DATA=true
```

## Demo accounts

All demo accounts use password `test1234`.

| Role | Email |
| --- | --- |
| Admin | admin@store.test |
| Manager | manager@store.test |
| Inventory | inventory@store.test |
| Fulfillment | fulfillment@store.test |
| Customer | customer@store.test |

## API overview

### SRS-compatible aliases

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/products`
- `GET /api/products/:slug`
- `POST /api/products` — admin/staff
- `POST /api/orders` — authenticated customer
- `GET /api/orders/user` — authenticated customer
- `GET /api/orders` — admin/staff
- `PUT /api/users/profile`
- `GET /api/users/wishlist`
- `PUT /api/users/wishlist`
- `PUT /api/users/addresses`

### Store routes

- `GET /api/store/products`
- `GET /api/store/products/:slug`
- `GET /api/store/collections`
- `POST /api/store/orders`
- `GET /api/store/orders/my`
- `GET /api/store/orders/track/:trackingNumber`
- `GET /api/store/admin/dashboard`
- `GET /api/store/admin/products`
- `POST /api/store/admin/products`
- `PUT /api/store/admin/products/:id`
- `PATCH /api/store/admin/products/:id/stock`
- `DELETE /api/store/admin/products/:id`
- `GET /api/store/admin/orders`
- `PATCH /api/store/admin/orders/:id/status`
- `GET /api/store/admin/inventory`
- `GET /api/store/admin/collections`
- `POST /api/store/admin/collections`
- `PUT /api/store/admin/collections/:id`
- `DELETE /api/store/admin/collections/:id`

## Important files

- `client/src/App.jsx` — storefront, products, cart, checkout, tracking, account, and admin UI
- `client/src/App.css` — responsive black/white UrbanWear styling
- `client/src/data/homepageData.js` — fashion categories, services, brands, and footer data
- `client/src/services/storeService.js` — frontend API client
- `server/models/Product.js` — variant-based fashion product schema
- `server/models/User.js` — profile, wishlist, and addresses
- `server/models/Order.js` — order items with size/color
- `server/models/Collection.js` — seasonal collections
- `server/controllers/storeController.js` — store, order, inventory, and collection API logic
- `server/routes/srsRoutes.js` — SRS route aliases
- `server/middleware/rateLimiter.js` — API rate limiter
- `server/services/storeSeedService.js` — UrbanWear demo catalog and collections

## Notes

- Checkout is blocked for guests to match the SRS requirement: guests can browse but cannot purchase.
- The included payment options are placeholders/manual flows. Connect a real payment gateway before production use.
- Replace `https://example.com/` in metadata, robots, and sitemap with your real domain before deployment.
#
